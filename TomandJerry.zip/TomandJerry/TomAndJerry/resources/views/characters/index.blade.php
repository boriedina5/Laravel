<h2>Karakterek</h2>

<table>
    <thead>
        <tr>
            <th>Név</th>
            <th>Faj</th>
            <th>Ellenség?</th>
            <th>Erősség</th>
            <th>Első megjelenés</th>
            <th>Műveletek</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td>
                <a href="">Szerkesztés</a>

                <form action="" method="POST" style="display: inline">
                    <button type="submit">Törlés</button>
                </form>
            </td>
        </tr>
    </tbody>
</table>